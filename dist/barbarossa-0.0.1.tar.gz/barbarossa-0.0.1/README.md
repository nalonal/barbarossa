# barbarossa

<h2>Python Google Crawler</h2>
<p>Simple script to crawling google using <a href="https://developers.facebook.com/tools/debug/echo/?q=">Facebook Developers Tools Debug</a></p>